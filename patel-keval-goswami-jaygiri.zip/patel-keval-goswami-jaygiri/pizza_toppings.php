<?php 

include 'pizza_header.php'; 
?>


<div class="container">
  <div id="welcomeMessage"></div>
  <div id="text">Welcome to SET Pizza Shop! We only serve one large pizza which comes with sauce and cheese. Order yours today!</div>
  <div id="toppingList"></div>
  <div id="totalCost"></div>
</br>
  <button id="makeItButton">Make It!</button>
</div>
