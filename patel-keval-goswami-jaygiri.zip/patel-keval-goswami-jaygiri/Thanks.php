<?php include 'pizza_header.php'; 
?>

<div class="container content">

<h2>Thank You, <span id="userInput"></span>!</h2>
<p>Your order has been <span id="orderStatus"><?= $orderStatus ?></span>.</p>
  <a href="UserEntryForm.php" id="homepageClick" class="button-link">Home</a>
  </br>
</div>
  </br>