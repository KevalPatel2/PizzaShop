$(document).ready(function () {
    // Handle user form submission
    $('#userForm').submit(function (event) {
        event.preventDefault();
        var userInput = $('#userInput').val();

        // Send user input to handle_order.php
        $.ajax({
            type: 'POST',
            url: 'handle_order.php',
            data: JSON.stringify({ userInput: userInput }),
            contentType: 'application/json',
            success: function (resp) {
                const response = JSON.parse(resp);

                // Check if the order creation was successful
                if (response['status'] === 'success') {
                    $('#errorAlert').hide();

                    // Save user details in sessionStorage and redirect to pizza_toppings.php
                    sessionId = response.sessionId;
                    sessionStorage.setItem('userDetails', JSON.stringify({
                        sessionId: sessionId,
                        userInput: userInput,
                        listOfToppings: response.toppingPrices
                    }));
                    window.location.href = 'pizza_toppings.php';
                } else {
                    // Display error message
                    $('#errorAlert').text(response['message']).show();
                }
            },
            error: function (error) {
                console.error('Error creating a new session:', error);
            }
        });
    });

    // Retrieve user details from sessionStorage
    const userDetails = JSON.parse(sessionStorage.getItem('userDetails'));
    const firstName = userDetails?.userInput.split(' ')[0];
    const toppingPrices = userDetails?.listOfToppings;
    sessionId = userDetails?.sessionId;
    var totalCost = 10.00;

    // Display welcome message and initial total cost
    $('#totalCost').html('Total Cost: $' + totalCost.toFixed(2));
    $('#welcomeMessage').html('Ciao ' + firstName);

    // Populate topping checkboxes
    var toppingsForm = $('#toppingList');
    if (toppingPrices) {
        Object.keys(toppingPrices).forEach(function (topping) {
            var checkboxLabel = $('<label class="topping-label">'); // Create a label for each topping
            var checkbox = $('<input type="checkbox" name="topping">')
                .appendTo(checkboxLabel)
                .val(topping);
            checkboxLabel.append(' ' + ucfirst(topping) + ' - $' + `${toppingPrices[topping]}`);
            toppingsForm.append(checkboxLabel);
            toppingsForm.append('<br>'); // Add a line break after each topping entry
        });
    }
    

    // Handle checkbox change to update total cost
    $('input[type="checkbox"]').change(function () {
        var selectedToppings = $('input[type="checkbox"]:checked').map(function () {
            return $(this).val();
        }).get();

        // Send selected toppings to handle_order.php to update total cost
        $.ajax({
            type: 'POST',
            url: 'handle_order.php',
            data: JSON.stringify({ sessionId: sessionId, selectedToppings: selectedToppings }),
            contentType: 'application/json',
            success: function (resp) {
                var priceResp = JSON.parse(resp);
                if (priceResp.status === 'success') {
                    totalCost = priceResp.sessionDetails.totalCost.toFixed(2);
                    $('#totalCost').html('Total Cost: $' + totalCost);
                } else {
                    alert('Error updating total cost.');
                }
                $('#makeItButton').prop('disabled', totalCost < 10.00);
            },
            error: function (error) {
                console.error('Error updating total cost:', error);
            }
        });
    });

    // Handle "Make It!" button click
    $('#makeItButton').click(function () {
        // Send session ID to handle_order.php to finalize the order
        $.ajax({
            type: 'POST',
            url: 'handle_order.php',
            data: JSON.stringify({ sessionId: sessionId }),
            contentType: 'application/json',
            success: function (response) {
                var orderResponse = JSON.parse(response);
                if (orderResponse.status === 'success') {
                    sessionStorage.setItem('orderDetails', JSON.stringify(orderResponse.sessionDetails));
                    window.location.href = 'OrderConfirmation.php';
                } else {
                    alert('Error updating toppings information.');
                }
            },
            error: function (error) {
                console.error('Error updating toppings information:', error);
            }
        });
    });

    // Retrieve order details from sessionStorage
    const orderDetails = JSON.parse(sessionStorage.getItem('orderDetails'));

    // Display order details if available
    if (orderDetails && orderDetails.selectedToppings) {
        toppingsList = orderDetails.selectedToppings;
        totalCost = orderDetails.totalCost;

        var updatedToppingsList = toppingsList.map((topping) => {
            return ucfirst(topping) + '                     ' + '$' + toppingPrices[topping].toFixed(2) + '<br/>';
        });

        $('#orderDetails').html('Selected Toppings: <br/>' + updatedToppingsList + '<br>');
        $('#summaryCost').html('Total Cost: $' + totalCost.toFixed(2))
    }

    // Handle "Confirm" button click
    $('#confirmButton').click(function () {
        const orderDetails = JSON.parse(sessionStorage.getItem('orderDetails'))
        orderDetails['orderStatus'] = 'Confirmed';
            sessionStorage.setItem('orderDetails',JSON.stringify(orderDetails))
            window.location.href = 'Thanks.php'; 
    });

    // Handle "Cancel" button click
    $('#cancelButton').click(function () {
        const orderDetails = JSON.parse(sessionStorage.getItem('orderDetails'))
        orderDetails['orderStatus'] = 'Cancelled'
        sessionStorage.setItem('orderDetails',JSON.stringify(orderDetails))
        window.location.href = 'Thanks.php'; 
    });

    $('#homepageClick').click(function () {
        $.ajax({
            type: 'POST',
            url: 'handle_order.php',
            data: { destroySession: true },
            success: function (response) {
                var destroyResponse = JSON.parse(response);
                if (destroyResponse.status === 'success') {
                    sessionStorage.removeItem('orderDetails');
                    sessionStorage.removeItem('userDetails');
                    window.location.href = 'UserEntryForm.php';
                } else {
                    alert('Error destroying session.');
                }
            },
            error: function (error) {
                console.error('Error destroying session:', error);
            }
        });
    });


     const order= JSON.parse(sessionStorage.getItem('orderDetails'));

     if(order){
     $('#userInput').html(order.userInput);
     $('#orderStatus').html(order.orderStatus);
     }

});



// Function to capitalize the first letter of a string
function ucfirst(str) {
    return str.charAt(0).toUpperCase() + str.slice(1);
}
